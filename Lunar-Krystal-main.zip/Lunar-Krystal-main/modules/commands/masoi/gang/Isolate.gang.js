const Gang = require('./Gang');

module.exports = class Isolate extends Gang {};
